#include <iostream>
#include <vector>
#include <list>

int main()
{
	std::vector<int> v = { 1,2,3,4,5,6,7,8,9,10 };
	
	int s = sum(std::begin(v), std::end(v));
}